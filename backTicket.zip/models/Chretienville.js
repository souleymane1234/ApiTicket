const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const { isResolvable } = require("@hapi/joi/lib/common");

const chretienvilleSchema = new mongoose.Schema({
  lieuDeVote: {
    type: String,
    required: true,
  },
  candidat1: {
    type: String,
    required: true,
  },

  candidat2: {
    type: String,
    required: true,
  },
  candidat3: {
    type: String,
    required: true,
  },
  candidat4: {
    type: String,
    required: true,
  },
  candidat5: {
    type: String,
    required: true,
  },
  voixCandidat1: {
    type: String,
    required: true,
  },
  voixCandidat2: {
    type: String,
    required: true,
  },
  voixCandidat3: {
    type: String,
    required: true,
  },
  voixCandidat4: {
    type: String,
    required: true,
  },
  voixCandidat5: {
    type: String,
    required: true,
  },
  nombreVotant: {
    type: String,
    required: true,
  },
  bulletinNull: {
    type: String,
    required: true,
  },
  bulletinBlanc: {
    type: String,
    required: true,
  },
  created_at: {
    type: Date,
    default: Date.now,
  },
  updated_at: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model("Chretienville", chretienvilleSchema);
