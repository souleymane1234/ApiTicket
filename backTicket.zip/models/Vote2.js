const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const { isResolvable } = require("@hapi/joi/lib/common");

const vote2Schema = new mongoose.Schema({
  lieuDeVote: {
    type: String,
    required: true,
  },
  candidat1: {
    type: String,
    required: true,
  },

  candidat2: {
    type: String,
    required: true,
  },
  voixCandidat1: {
    type: String,
    required: true,
  },
  voixCandidat2: {
    type: String,
    required: true,
  },
  created_at: {
    type: Date,
    default: Date.now,
  },
  updated_at: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model("Vote2", vote2Schema);
