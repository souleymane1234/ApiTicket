const express = require("express");
const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
const { jwtKey } = require("../keys");
const router = express.Router();
const Sokouradjans = mongoose.model("Sokouradjans");
const Prisoncivile = mongoose.model("Prisoncivile");
const Akessemossou = mongoose.model("Akessemossou");
const Bassayobouessou = mongoose.model("Bassayobouessou");
const Belleville = mongoose.model("Belleville");
const Benediction = mongoose.model("Benediction");
const Chretienville = mongoose.model("Chretienville");

const Christroi = mongoose.model("Christroi");
const Collegemoderne = mongoose.model("Collegemoderne");
const Dioulakro = mongoose.model("Bassayobouessou");
const Endemies = mongoose.model("Endemies");
const Eppahouniassou = mongoose.model("Eppahouniassou");
const Eppahua = mongoose.model("Eppahua");

const Eppdadiekouassikro = mongoose.model("Eppdadiekouassikro");
const Eppandianou = mongoose.model("Eppandianou");
const Eppdioulakro = mongoose.model("Eppdioulakro");
const Eppebimolossou = mongoose.model("Eppebimolossou");
const Eppkadjabo = mongoose.model("Eppkadjabo");
const Eppkangrassou = mongoose.model("Eppkangrassou");

const Eppkoffiahoussoukro = mongoose.model("Eppkoffiahoussoukro");
const Eppkrokokro = mongoose.model("Eppkrokokro");
const Eppplateautrois = mongoose.model("Eppplateautrois");
const Eppsoungassi = mongoose.model("Eppsoungassi");
const Eppsoungassou = mongoose.model("Eppsoungassou");
const Epptangoumanssou = mongoose.model("Epptangoumanssou");

const Epptromabo = mongoose.model("Epptromabo");
const Eppwawrenou = mongoose.model("Eppwawrenou");
const Epvcatholique = mongoose.model("Epvcatholique");
const Faiteassou = mongoose.model("Faiteassou");
const Hopital = mongoose.model("Hopital");
const Kangrassouyobouebo = mongoose.model("Kangrassouyobouebo");

const Koffiackant = mongoose.model("Koffiackant");
const Koffikro = mongoose.model("Koffikro");
const Kolibo = mongoose.model("Kolibo");
const Komikro = mongoose.model("Komikro");
const Niamanssou = mongoose.model("Niamanssou");
const Pmi = mongoose.model("Pmi");

const Utexi = mongoose.model("Utexi");

// create post API start
router.post("/api/createVoteSokouradjans", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Sokouradjans({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVotePrisoncivile", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Prisoncivile({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteAkessemossou", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Akessemossou({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteBassayobouessou", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Bassayobouessou({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteBelleville", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Belleville({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteBenediction", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Benediction({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteChretienville", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Chretienville({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteChristroi", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Christroi({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteCollegemoderne", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Collegemoderne({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteDioulakro", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Dioulakro({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteEndemies", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Endemies({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteEppahouniassou", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Eppahouniassou({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteEppahua", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Eppahua({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteEppdadiekouassikro", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Eppdadiekouassikro({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteEppandianou", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Eppandianou({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteEppdioulakro", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Eppdioulakro({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteEppebimolossou", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Eppebimolossou({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteEppkadjabo", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Eppkadjabo({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteEppkangrassou", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Eppkangrassou({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteEppkoffiahoussoukro", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Eppkoffiahoussoukro({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteEppkrokokro", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Eppkrokokro({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteEppplateautrois", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Eppplateautrois({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteEppsoungassi", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Eppsoungassi({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteEppsoungassou", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Eppsoungassou({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteEpptangoumanssou", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Epptangoumanssou({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteEpptromabo", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Epptromabo({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteEppwawrenou", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Eppwawrenou({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteEpvcatholique", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Epvcatholique({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteFaiteassou", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Faiteassou({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteHopital", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Hopital({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteKangrassouyobouebo", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Kangrassouyobouebo({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteKoffiackant", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Koffiackant({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteKoffikro", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Koffikro({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteKolibo", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Kolibo({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteKomikro", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Komikro({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteNiamanssou", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Niamanssou({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVotePmi", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Pmi({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

router.post("/api/createVoteUtexi", async (req, res) => {
  const {
    lieuDeVote,
    candidat1,
    candidat2,
    candidat3,
    candidat4,
    candidat5,
    voixCandidat1,
    voixCandidat2,
    voixCandidat3,
    voixCandidat4,
    voixCandidat5,
    nombreVotant,
    bulletinNull,
    bulletinBlanc,
    created_at,
    updated_at,
  } = req.body;
  try {
    const votes = new Utexi({
      lieuDeVote,
      candidat1,
      candidat2,
      candidat3,
      candidat4,
      candidat5,
      voixCandidat1,
      voixCandidat2,
      voixCandidat3,
      voixCandidat4,
      voixCandidat5,
      nombreVotant,
      bulletinNull,
      bulletinBlanc,
      created_at,
      updated_at,
    });
    await votes.save();
    res.json(votes);
  } catch (err) {
    res.status(422).send(err.message);
  }
});

// create post API end

// get all vote API start
router.get("/api/allVoteSokouradjan", (req, res) => {
  Sokouradjans.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVotePrisoncivile", (req, res) => {
  Prisoncivile.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteAkessemossou", (req, res) => {
  Akessemossou.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteBassayobouessou", (req, res) => {
  Bassayobouessou.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteBelleville", (req, res) => {
  Belleville.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteBenediction", (req, res) => {
  Benediction.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteChretienville", (req, res) => {
  Chretienville.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteChristroi", (req, res) => {
  Christroi.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteCollegemoderne", (req, res) => {
  Collegemoderne.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteDioulakro", (req, res) => {
  Dioulakro.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteEndemies", (req, res) => {
  Endemies.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteEppahouniassou", (req, res) => {
  Eppahouniassou.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteEppahua", (req, res) => {
  Eppahua.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteEppdadiekouassikro", (req, res) => {
  Eppdadiekouassikro.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteEppandianou", (req, res) => {
  Eppandianou.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteEppdioulakro", (req, res) => {
  Eppdioulakro.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteEppebimolossou", (req, res) => {
  Eppebimolossou.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteEppkadjabo", (req, res) => {
  Eppkadjabo.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteEppkangrassou", (req, res) => {
  Eppkangrassou.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteEppkoffiahoussoukro", (req, res) => {
  Eppkoffiahoussoukro.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteEppkrokokro", (req, res) => {
  Eppkrokokro.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteEppplateautrois", (req, res) => {
  Eppplateautrois.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteEppsoungassi", (req, res) => {
  Eppsoungassi.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteEppsoungassou", (req, res) => {
  Eppsoungassou.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteEpptangoumanssou", (req, res) => {
  Epptangoumanssou.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteEpptromabo", (req, res) => {
  Epptromabo.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteEppwawrenou", (req, res) => {
  Eppwawrenou.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteEpvcatholique", (req, res) => {
  Epvcatholique.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteFaiteassou", (req, res) => {
  Faiteassou.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteHopital", (req, res) => {
  Hopital.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteKangrassouyobouebo", (req, res) => {
  Kangrassouyobouebo.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteKoffiackant", (req, res) => {
  Koffiackant.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteKoffikro", (req, res) => {
  Koffikro.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteKolibo", (req, res) => {
  Kolibo.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteKomikro", (req, res) => {
  Komikro.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteNiamanssou", (req, res) => {
  Niamanssou.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVotePmi", (req, res) => {
  Pmi.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});

router.get("/api/allVoteUtexi", (req, res) => {
  Utexi.find({}, (err, data) => {
    if (!err) {
      res.send(data);
    } else {
      console.log(err);
    }
  });
});
// get all vote API end

module.exports = router;
